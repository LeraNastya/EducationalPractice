﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        string connectionString = "Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";

        [TestMethod]
        public void Test_Users_Count()
        {
            // Подготовка теста: создание запроса для получения всех логинов
            string querystring = $"select Пользователи.Логин from Пользователи";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            // Проверка результата: ожидается, что таблица будет содержать 9 строк
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(9, table.Rows.Count);
        }

        [TestMethod]
        public void Test_Tovar_Count()
        {
            // Подготовка теста: создание запроса для получения всех логинов
            string querystring = $"select Название_товара from Товары";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            // Проверка результата: ожидается, что таблица будет содержать 6 строк
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(6, table.Rows.Count);
        }

        [TestMethod]
        public void Test_Zakaz_Count()
        {
            // Подготовка теста: создание запроса для получения всех логинов
            string querystring = $"select Номер_заказа from Заказы";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            // Проверка результата: ожидается, что таблица будет содержать 3 строки
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(3, table.Rows.Count);
        }

        [TestMethod]
        public void GetQuantityForProduct_NoLogin()
        {
            // Подготовка теста: создание запроса с пустым логино
            string querystring = $"select Логин, Пароль, Роль from Пользователи where Логин =''";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            // Проверка результата: ожидается, что таблица будет пустой (0 строк)
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(0, table.Rows.Count);
        }


        [TestMethod]
        public void GetQuantityForProduct_CorrectLogin()
        {
            // Подготовка теста: создание запроса с корректными логином и паролем
            string querystring = $"select Логин, Пароль, Роль from Пользователи where Логин ='Анастасия' and Пароль= '66666'  ";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            // Проверка результата: ожидается, что таблица будет содержать одну строку (1 пользователь)
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual(1, table.Rows.Count);
        }

        [TestMethod]
        public void LookFor_Zakaz()
        {
            string querystring = $"select Название_товара from Заказы where Номер_заказа = 1";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual("1_орхидея", table.Rows[0]["Название_товара"].ToString());
        }

        [TestMethod]
        public void LookFor_Client()
        {
            string querystring = $"select Телефон from Клиенты where Номер_клиента = 1";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual("89215576843", table.Rows[0]["телефон"].ToString());
        }

        [TestMethod]
        public void LookFor_Meneger()
        {
            string querystring = $"select Дата_приема_на_работу from Менеджеры where Номер_менеджера = 1";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual("12.11.2022", table.Rows[0]["Дата_приема_на_работу"].ToString());
        }

        [TestMethod]
        public void Check_Meneger_not_exists()
        {
            // Подготовка теста: создание запроса для получения всех логинов менеджеров
            string querystring = $"select Логин from Пользователи where Роль = 'менеджер'";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreNotEqual("Александр", table.Rows[0]["Логин"].ToString());
        }

        [TestMethod]
        public void Check_Meneger_exists()
        {
            // Подготовка теста: создание запроса для получения всех логинов менеджеров
            string querystring = $"select Логин from Пользователи where Роль = 'менеджер'";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connectionString);

            // Выполнение теста: заполнение DataTable данными из базы данных
            DataTable table = new DataTable();
            adapter.Fill(table);

            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.AreEqual("Александра", table.Rows[0]["Логин"].ToString());
        }
    }
}
