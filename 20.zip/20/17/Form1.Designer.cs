﻿namespace _17
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.button21 = new System.Windows.Forms.Button();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.button22 = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.номерклиентаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.логинклиентаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.телефонDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Тихонова_4_курс_практикаDataSet5 = new _17.____Тихонова_4_курс_практикаDataSet5();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.пользователиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Tihonova_TuristichClubDataSet6 = new _17.____Tihonova_TuristichClubDataSet6();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.номерменеджераDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.логинменеджераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.имяменеджераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.окладDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаприеманаработуDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.менеджерыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Тихонова_4_курс_практикаDataSet4 = new _17.____Тихонова_4_курс_практикаDataSet4();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.оплатаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Tihonova_TuristichClubDataSet5 = new _17.____Tihonova_TuristichClubDataSet5();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.button17 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.номерпоставщикаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.имяпоставщикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номеравтомобиляDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.поставщикиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Тихонова_4_курс_практикаDataSet3 = new _17.____Тихонова_4_курс_практикаDataSet3();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.пунктназначенияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Tihonova_TuristichClubDataSet4 = new _17.____Tihonova_TuristichClubDataSet4();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.номерзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерклиентаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датадобавленияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиетовараDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествотовараDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.срокипоставкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.статусзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерменеджераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерпоставщикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.заказыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Тихонова_4_курс_практикаDataSet2 = new _17.____Тихонова_4_курс_практикаDataSet2();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.маршрут2BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.____Tihonova_TuristichClubDataSet10 = new _17.____Tihonova_TuristichClubDataSet10();
            this.маршрутBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Tihonova_TuristichClubDataSet3 = new _17.____Tihonova_TuristichClubDataSet3();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.названиетовараDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.полноеназваниеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.условиясодержанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.товарыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Тихонова_4_курс_практикаDataSet1 = new _17.____Тихонова_4_курс_практикаDataSet1();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.уровеньсложностиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.____Tihonova_TuristichClubDataSet2 = new _17.____Tihonova_TuristichClubDataSet2();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.button11 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.button26 = new System.Windows.Forms.Button();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.логинDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.парольDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.рольDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.пользователиBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.____Тихонова_4_курс_практикаDataSet7 = new _17.____Тихонова_4_курс_практикаDataSet7();
            this.пользователиBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.____Тихонова_4_курс_практикаDataSet6 = new _17.____Тихонова_4_курс_практикаDataSet6();
            this.уровень_сложностиTableAdapter = new _17.____Tihonova_TuristichClubDataSet2TableAdapters.уровень_сложностиTableAdapter();
            this.маршрутTableAdapter = new _17.____Tihonova_TuristichClubDataSet3TableAdapters.маршрутTableAdapter();
            this.пункт_назначенияTableAdapter = new _17.____Tihonova_TuristichClubDataSet4TableAdapters.пункт_назначенияTableAdapter();
            this.оплатаTableAdapter = new _17.____Tihonova_TuristichClubDataSet5TableAdapters.оплатаTableAdapter();
            this.пользователиTableAdapter = new _17.____Tihonova_TuristichClubDataSet6TableAdapters.пользователиTableAdapter();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.____Tihonova_TuristichClubDataSet9 = new _17.____Tihonova_TuristichClubDataSet9();
            this.маршрут2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.маршрут2TableAdapter = new _17.____Tihonova_TuristichClubDataSet9TableAdapters.маршрут2TableAdapter();
            this.маршрут2TableAdapter1 = new _17.____Tihonova_TuristichClubDataSet10TableAdapters.маршрут2TableAdapter();
            this.товарыTableAdapter = new _17.____Тихонова_4_курс_практикаDataSet1TableAdapters.ТоварыTableAdapter();
            this.заказыTableAdapter = new _17.____Тихонова_4_курс_практикаDataSet2TableAdapters.ЗаказыTableAdapter();
            this.поставщикиTableAdapter = new _17.____Тихонова_4_курс_практикаDataSet3TableAdapters.ПоставщикиTableAdapter();
            this.менеджерыTableAdapter = new _17.____Тихонова_4_курс_практикаDataSet4TableAdapters.МенеджерыTableAdapter();
            this.клиентыTableAdapter = new _17.____Тихонова_4_курс_практикаDataSet5TableAdapters.КлиентыTableAdapter();
            this.пользователиTableAdapter1 = new _17.____Тихонова_4_курс_практикаDataSet6TableAdapters.ПользователиTableAdapter();
            this.пользователиTableAdapter2 = new _17.____Тихонова_4_курс_практикаDataSet7TableAdapters.ПользователиTableAdapter();
            this.tabPage5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet5)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet6)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.менеджерыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet4)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.оплатаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet5)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.поставщикиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet3)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пунктназначенияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet4)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.маршрут2BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маршрутBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet3)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.уровеньсложностиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.маршрут2BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Green;
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Controls.Add(this.groupBox10);
            this.tabPage5.Controls.Add(this.dataGridView5);
            this.tabPage5.Controls.Add(this.panel5);
            this.tabPage5.Location = new System.Drawing.Point(4, 27);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1047, 400);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Клиенты";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.radioButton9);
            this.groupBox9.Controls.Add(this.radioButton10);
            this.groupBox9.Controls.Add(this.button21);
            this.groupBox9.Controls.Add(this.comboBox5);
            this.groupBox9.Location = new System.Drawing.Point(673, 127);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(338, 225);
            this.groupBox9.TabIndex = 35;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Сортировка по";
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(7, 130);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(149, 22);
            this.radioButton9.TabIndex = 30;
            this.radioButton9.Text = "По возрастанию";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Checked = true;
            this.radioButton10.Location = new System.Drawing.Point(7, 102);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(126, 22);
            this.radioButton10.TabIndex = 29;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "По убыванию";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.YellowGreen;
            this.button21.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button21.Location = new System.Drawing.Point(178, 44);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(35, 28);
            this.button21.TabIndex = 28;
            this.button21.Text = "L";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // comboBox5
            // 
            this.comboBox5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Номер",
            "Логин",
            "Телефон"});
            this.comboBox5.Location = new System.Drawing.Point(6, 44);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(156, 27);
            this.comboBox5.TabIndex = 28;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox20);
            this.groupBox10.Controls.Add(this.button22);
            this.groupBox10.Location = new System.Drawing.Point(673, 18);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(338, 100);
            this.groupBox10.TabIndex = 34;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Поиск по логину";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(6, 43);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 25);
            this.textBox20.TabIndex = 26;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.YellowGreen;
            this.button22.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button22.Location = new System.Drawing.Point(127, 43);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(35, 28);
            this.button22.TabIndex = 27;
            this.button22.Text = "L";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // dataGridView5
            // 
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номерклиентаDataGridViewTextBoxColumn1,
            this.логинклиентаDataGridViewTextBoxColumn,
            this.телефонDataGridViewTextBoxColumn});
            this.dataGridView5.DataSource = this.клиентыBindingSource;
            this.dataGridView5.Enabled = false;
            this.dataGridView5.Location = new System.Drawing.Point(16, 18);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(581, 150);
            this.dataGridView5.TabIndex = 32;
            // 
            // номерклиентаDataGridViewTextBoxColumn1
            // 
            this.номерклиентаDataGridViewTextBoxColumn1.DataPropertyName = "Номер_клиента";
            this.номерклиентаDataGridViewTextBoxColumn1.HeaderText = "Номер_клиента";
            this.номерклиентаDataGridViewTextBoxColumn1.Name = "номерклиентаDataGridViewTextBoxColumn1";
            this.номерклиентаDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // логинклиентаDataGridViewTextBoxColumn
            // 
            this.логинклиентаDataGridViewTextBoxColumn.DataPropertyName = "Логин_клиента";
            this.логинклиентаDataGridViewTextBoxColumn.HeaderText = "Логин_клиента";
            this.логинклиентаDataGridViewTextBoxColumn.Name = "логинклиентаDataGridViewTextBoxColumn";
            // 
            // телефонDataGridViewTextBoxColumn
            // 
            this.телефонDataGridViewTextBoxColumn.DataPropertyName = "Телефон";
            this.телефонDataGridViewTextBoxColumn.HeaderText = "Телефон";
            this.телефонDataGridViewTextBoxColumn.Name = "телефонDataGridViewTextBoxColumn";
            // 
            // клиентыBindingSource
            // 
            this.клиентыBindingSource.DataMember = "Клиенты";
            this.клиентыBindingSource.DataSource = this.____Тихонова_4_курс_практикаDataSet5;
            // 
            // ____Тихонова_4_курс_практикаDataSet5
            // 
            this.____Тихонова_4_курс_практикаDataSet5.DataSetName = "____Тихонова_4_курс_практикаDataSet5";
            this.____Тихонова_4_курс_практикаDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.textBox25);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.button23);
            this.panel5.Controls.Add(this.button24);
            this.panel5.Controls.Add(this.button25);
            this.panel5.Controls.Add(this.textBox26);
            this.panel5.Controls.Add(this.textBox27);
            this.panel5.Controls.Add(this.label25);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Location = new System.Drawing.Point(16, 183);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(581, 169);
            this.panel5.TabIndex = 33;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(213, 99);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(159, 25);
            this.textBox25.TabIndex = 28;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(41, 102);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(75, 18);
            this.label24.TabIndex = 25;
            this.label24.Text = "Телефон";
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.YellowGreen;
            this.button23.Location = new System.Drawing.Point(420, 100);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(92, 23);
            this.button23.TabIndex = 24;
            this.button23.Text = "Удалить";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.YellowGreen;
            this.button24.Location = new System.Drawing.Point(420, 63);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(92, 23);
            this.button24.TabIndex = 23;
            this.button24.Text = "Изменить";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.YellowGreen;
            this.button25.Location = new System.Drawing.Point(420, 29);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(92, 23);
            this.button25.TabIndex = 22;
            this.button25.Text = "Добавить";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(213, 63);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(159, 25);
            this.textBox26.TabIndex = 12;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(213, 29);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(159, 25);
            this.textBox27.TabIndex = 11;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(41, 66);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(119, 18);
            this.label25.TabIndex = 1;
            this.label25.Text = "Логин клиента";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(41, 29);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(123, 18);
            this.label26.TabIndex = 0;
            this.label26.Text = "Номер клиента";
            // 
            // пользователиBindingSource
            // 
            this.пользователиBindingSource.DataMember = "пользователи";
            this.пользователиBindingSource.DataSource = this.____Tihonova_TuristichClubDataSet6;
            // 
            // ____Tihonova_TuristichClubDataSet6
            // 
            this.____Tihonova_TuristichClubDataSet6.DataSetName = "____Tihonova_TuristichClubDataSet6";
            this.____Tihonova_TuristichClubDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.MediumPurple;
            this.tabPage4.Controls.Add(this.groupBox6);
            this.tabPage4.Controls.Add(this.dataGridView2);
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.Location = new System.Drawing.Point(4, 27);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1047, 400);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Менеджеры";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox12);
            this.groupBox6.Controls.Add(this.button12);
            this.groupBox6.Location = new System.Drawing.Point(749, 20);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(238, 97);
            this.groupBox6.TabIndex = 38;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Поиск по номеру менеджера";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(6, 43);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 25);
            this.textBox12.TabIndex = 26;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.BlueViolet;
            this.button12.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button12.Location = new System.Drawing.Point(127, 43);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(35, 28);
            this.button12.TabIndex = 27;
            this.button12.Text = "L";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номерменеджераDataGridViewTextBoxColumn1,
            this.логинменеджераDataGridViewTextBoxColumn,
            this.имяменеджераDataGridViewTextBoxColumn,
            this.окладDataGridViewTextBoxColumn,
            this.датаприеманаработуDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.менеджерыBindingSource;
            this.dataGridView2.Enabled = false;
            this.dataGridView2.Location = new System.Drawing.Point(14, 20);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(672, 150);
            this.dataGridView2.TabIndex = 36;
            // 
            // номерменеджераDataGridViewTextBoxColumn1
            // 
            this.номерменеджераDataGridViewTextBoxColumn1.DataPropertyName = "Номер_менеджера";
            this.номерменеджераDataGridViewTextBoxColumn1.HeaderText = "Номер_менеджера";
            this.номерменеджераDataGridViewTextBoxColumn1.Name = "номерменеджераDataGridViewTextBoxColumn1";
            this.номерменеджераDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // логинменеджераDataGridViewTextBoxColumn
            // 
            this.логинменеджераDataGridViewTextBoxColumn.DataPropertyName = "Логин_менеджера";
            this.логинменеджераDataGridViewTextBoxColumn.HeaderText = "Логин_менеджера";
            this.логинменеджераDataGridViewTextBoxColumn.Name = "логинменеджераDataGridViewTextBoxColumn";
            // 
            // имяменеджераDataGridViewTextBoxColumn
            // 
            this.имяменеджераDataGridViewTextBoxColumn.DataPropertyName = "Имя_менеджера";
            this.имяменеджераDataGridViewTextBoxColumn.HeaderText = "Имя_менеджера";
            this.имяменеджераDataGridViewTextBoxColumn.Name = "имяменеджераDataGridViewTextBoxColumn";
            // 
            // окладDataGridViewTextBoxColumn
            // 
            this.окладDataGridViewTextBoxColumn.DataPropertyName = "Оклад";
            this.окладDataGridViewTextBoxColumn.HeaderText = "Оклад";
            this.окладDataGridViewTextBoxColumn.Name = "окладDataGridViewTextBoxColumn";
            // 
            // датаприеманаработуDataGridViewTextBoxColumn
            // 
            this.датаприеманаработуDataGridViewTextBoxColumn.DataPropertyName = "Дата_приема_на_работу";
            this.датаприеманаработуDataGridViewTextBoxColumn.HeaderText = "Дата_приема_на_работу";
            this.датаприеманаработуDataGridViewTextBoxColumn.Name = "датаприеманаработуDataGridViewTextBoxColumn";
            // 
            // менеджерыBindingSource
            // 
            this.менеджерыBindingSource.DataMember = "Менеджеры";
            this.менеджерыBindingSource.DataSource = this.____Тихонова_4_курс_практикаDataSet4;
            // 
            // ____Тихонова_4_курс_практикаDataSet4
            // 
            this.____Тихонова_4_курс_практикаDataSet4.DataSetName = "____Тихонова_4_курс_практикаDataSet4";
            this.____Тихонова_4_курс_практикаDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.textBox29);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.textBox16);
            this.panel3.Controls.Add(this.textBox17);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.button13);
            this.panel3.Controls.Add(this.button14);
            this.panel3.Controls.Add(this.button15);
            this.panel3.Controls.Add(this.textBox18);
            this.panel3.Controls.Add(this.textBox19);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Location = new System.Drawing.Point(14, 185);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(672, 200);
            this.panel3.TabIndex = 37;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(264, 162);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(159, 25);
            this.textBox29.TabIndex = 31;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(71, 162);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(189, 18);
            this.label11.TabIndex = 30;
            this.label11.Text = "Дата приема на работу";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(264, 124);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(159, 25);
            this.textBox16.TabIndex = 29;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(264, 86);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(159, 25);
            this.textBox17.TabIndex = 28;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(71, 123);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 18);
            this.label16.TabIndex = 26;
            this.label16.Text = "Оклад";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(71, 89);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(127, 18);
            this.label17.TabIndex = 25;
            this.label17.Text = "Имя менеджера";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.BlueViolet;
            this.button13.Location = new System.Drawing.Point(471, 162);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(92, 23);
            this.button13.TabIndex = 24;
            this.button13.Text = "Удалить";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.BlueViolet;
            this.button14.Location = new System.Drawing.Point(471, 86);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(92, 23);
            this.button14.TabIndex = 23;
            this.button14.Text = "Изменить";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.BlueViolet;
            this.button15.Location = new System.Drawing.Point(471, 18);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(92, 23);
            this.button15.TabIndex = 22;
            this.button15.Text = "Добавить";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(264, 50);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(159, 25);
            this.textBox18.TabIndex = 12;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(264, 16);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(159, 25);
            this.textBox19.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(71, 51);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(141, 18);
            this.label18.TabIndex = 1;
            this.label18.Text = "Логин менеджера";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(71, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(145, 18);
            this.label19.TabIndex = 0;
            this.label19.Text = "Номер менеджера";
            // 
            // оплатаBindingSource
            // 
            this.оплатаBindingSource.DataMember = "оплата";
            this.оплатаBindingSource.DataSource = this.____Tihonova_TuristichClubDataSet5;
            // 
            // ____Tihonova_TuristichClubDataSet5
            // 
            this.____Tihonova_TuristichClubDataSet5.DataSetName = "____Tihonova_TuristichClubDataSet5";
            this.____Tihonova_TuristichClubDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.MediumPurple;
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.dataGridView4);
            this.tabPage3.Controls.Add(this.panel4);
            this.tabPage3.Location = new System.Drawing.Point(4, 27);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1047, 400);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Поставщики";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBox13);
            this.groupBox8.Controls.Add(this.button17);
            this.groupBox8.Location = new System.Drawing.Point(713, 17);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(187, 100);
            this.groupBox8.TabIndex = 33;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Поиск по номеру поставщика";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(6, 43);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 25);
            this.textBox13.TabIndex = 26;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.BlueViolet;
            this.button17.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button17.Location = new System.Drawing.Point(127, 43);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(35, 28);
            this.button17.TabIndex = 27;
            this.button17.Text = "L";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номерпоставщикаDataGridViewTextBoxColumn1,
            this.имяпоставщикаDataGridViewTextBoxColumn,
            this.номеравтомобиляDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.поставщикиBindingSource;
            this.dataGridView4.Enabled = false;
            this.dataGridView4.Location = new System.Drawing.Point(16, 17);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(376, 366);
            this.dataGridView4.TabIndex = 31;
            // 
            // номерпоставщикаDataGridViewTextBoxColumn1
            // 
            this.номерпоставщикаDataGridViewTextBoxColumn1.DataPropertyName = "Номер_поставщика";
            this.номерпоставщикаDataGridViewTextBoxColumn1.HeaderText = "Номер_поставщика";
            this.номерпоставщикаDataGridViewTextBoxColumn1.Name = "номерпоставщикаDataGridViewTextBoxColumn1";
            // 
            // имяпоставщикаDataGridViewTextBoxColumn
            // 
            this.имяпоставщикаDataGridViewTextBoxColumn.DataPropertyName = "Имя_поставщика";
            this.имяпоставщикаDataGridViewTextBoxColumn.HeaderText = "Имя_поставщика";
            this.имяпоставщикаDataGridViewTextBoxColumn.Name = "имяпоставщикаDataGridViewTextBoxColumn";
            // 
            // номеравтомобиляDataGridViewTextBoxColumn
            // 
            this.номеравтомобиляDataGridViewTextBoxColumn.DataPropertyName = "Номер_автомобиля";
            this.номеравтомобиляDataGridViewTextBoxColumn.HeaderText = "Номер_автомобиля";
            this.номеравтомобиляDataGridViewTextBoxColumn.Name = "номеравтомобиляDataGridViewTextBoxColumn";
            // 
            // поставщикиBindingSource
            // 
            this.поставщикиBindingSource.DataMember = "Поставщики";
            this.поставщикиBindingSource.DataSource = this.____Тихонова_4_курс_практикаDataSet3;
            // 
            // ____Тихонова_4_курс_практикаDataSet3
            // 
            this.____Тихонова_4_курс_практикаDataSet3.DataSetName = "____Тихонова_4_курс_практикаDataSet3";
            this.____Тихонова_4_курс_практикаDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox6);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.button18);
            this.panel4.Controls.Add(this.button19);
            this.panel4.Controls.Add(this.button20);
            this.panel4.Controls.Add(this.textBox14);
            this.panel4.Controls.Add(this.textBox15);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(457, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(203, 366);
            this.panel4.TabIndex = 32;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(20, 200);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(159, 25);
            this.textBox6.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 168);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 18);
            this.label1.TabIndex = 25;
            this.label1.Text = "Номер автомобиля";
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.BlueViolet;
            this.button18.Location = new System.Drawing.Point(56, 327);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(92, 23);
            this.button18.TabIndex = 24;
            this.button18.Text = "Удалить";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.BlueViolet;
            this.button19.Location = new System.Drawing.Point(56, 289);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(92, 23);
            this.button19.TabIndex = 23;
            this.button19.Text = "Изменить";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.BlueViolet;
            this.button20.Location = new System.Drawing.Point(56, 247);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(92, 23);
            this.button20.TabIndex = 22;
            this.button20.Text = "Добавить";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(21, 46);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(159, 25);
            this.textBox14.TabIndex = 12;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(21, 122);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(159, 25);
            this.textBox15.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Имя поставщика";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 18);
            this.label4.TabIndex = 0;
            this.label4.Text = "Номер поставщика";
            // 
            // пунктназначенияBindingSource
            // 
            this.пунктназначенияBindingSource.DataMember = "пункт_назначения";
            this.пунктназначенияBindingSource.DataSource = this.____Tihonova_TuristichClubDataSet4;
            // 
            // ____Tihonova_TuristichClubDataSet4
            // 
            this.____Tihonova_TuristichClubDataSet4.DataSetName = "____Tihonova_TuristichClubDataSet4";
            this.____Tihonova_TuristichClubDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Green;
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.dataGridView3);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1047, 400);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Заказы";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Location = new System.Drawing.Point(791, 281);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(238, 105);
            this.groupBox2.TabIndex = 31;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Количество выполненных заказов";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(92, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 18);
            this.label10.TabIndex = 28;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.YellowGreen;
            this.button8.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button8.Location = new System.Drawing.Point(26, 64);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(35, 28);
            this.button8.TabIndex = 27;
            this.button8.Text = "L";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номерзаказаDataGridViewTextBoxColumn,
            this.номерклиентаDataGridViewTextBoxColumn,
            this.датадобавленияDataGridViewTextBoxColumn,
            this.названиетовараDataGridViewTextBoxColumn1,
            this.количествотовараDataGridViewTextBoxColumn,
            this.срокипоставкиDataGridViewTextBoxColumn,
            this.статусзаказаDataGridViewTextBoxColumn,
            this.номерменеджераDataGridViewTextBoxColumn,
            this.номерпоставщикаDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.заказыBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(17, 19);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1012, 150);
            this.dataGridView3.TabIndex = 32;
            // 
            // номерзаказаDataGridViewTextBoxColumn
            // 
            this.номерзаказаDataGridViewTextBoxColumn.DataPropertyName = "Номер_заказа";
            this.номерзаказаDataGridViewTextBoxColumn.HeaderText = "Номер_заказа";
            this.номерзаказаDataGridViewTextBoxColumn.Name = "номерзаказаDataGridViewTextBoxColumn";
            this.номерзаказаDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // номерклиентаDataGridViewTextBoxColumn
            // 
            this.номерклиентаDataGridViewTextBoxColumn.DataPropertyName = "Номер_клиента";
            this.номерклиентаDataGridViewTextBoxColumn.HeaderText = "Номер_клиента";
            this.номерклиентаDataGridViewTextBoxColumn.Name = "номерклиентаDataGridViewTextBoxColumn";
            // 
            // датадобавленияDataGridViewTextBoxColumn
            // 
            this.датадобавленияDataGridViewTextBoxColumn.DataPropertyName = "Дата_добавления";
            this.датадобавленияDataGridViewTextBoxColumn.HeaderText = "Дата_добавления";
            this.датадобавленияDataGridViewTextBoxColumn.Name = "датадобавленияDataGridViewTextBoxColumn";
            // 
            // названиетовараDataGridViewTextBoxColumn1
            // 
            this.названиетовараDataGridViewTextBoxColumn1.DataPropertyName = "Название_товара";
            this.названиетовараDataGridViewTextBoxColumn1.HeaderText = "Название_товара";
            this.названиетовараDataGridViewTextBoxColumn1.Name = "названиетовараDataGridViewTextBoxColumn1";
            // 
            // количествотовараDataGridViewTextBoxColumn
            // 
            this.количествотовараDataGridViewTextBoxColumn.DataPropertyName = "Количество_товара";
            this.количествотовараDataGridViewTextBoxColumn.HeaderText = "Количество_товара";
            this.количествотовараDataGridViewTextBoxColumn.Name = "количествотовараDataGridViewTextBoxColumn";
            // 
            // срокипоставкиDataGridViewTextBoxColumn
            // 
            this.срокипоставкиDataGridViewTextBoxColumn.DataPropertyName = "Сроки_поставки";
            this.срокипоставкиDataGridViewTextBoxColumn.HeaderText = "Сроки_поставки";
            this.срокипоставкиDataGridViewTextBoxColumn.Name = "срокипоставкиDataGridViewTextBoxColumn";
            // 
            // статусзаказаDataGridViewTextBoxColumn
            // 
            this.статусзаказаDataGridViewTextBoxColumn.DataPropertyName = "Статус_заказа";
            this.статусзаказаDataGridViewTextBoxColumn.HeaderText = "Статус_заказа";
            this.статусзаказаDataGridViewTextBoxColumn.Name = "статусзаказаDataGridViewTextBoxColumn";
            // 
            // номерменеджераDataGridViewTextBoxColumn
            // 
            this.номерменеджераDataGridViewTextBoxColumn.DataPropertyName = "Номер_менеджера";
            this.номерменеджераDataGridViewTextBoxColumn.HeaderText = "Номер_менеджера";
            this.номерменеджераDataGridViewTextBoxColumn.Name = "номерменеджераDataGridViewTextBoxColumn";
            // 
            // номерпоставщикаDataGridViewTextBoxColumn
            // 
            this.номерпоставщикаDataGridViewTextBoxColumn.DataPropertyName = "Номер_поставщика";
            this.номерпоставщикаDataGridViewTextBoxColumn.HeaderText = "Номер_поставщика";
            this.номерпоставщикаDataGridViewTextBoxColumn.Name = "номерпоставщикаDataGridViewTextBoxColumn";
            // 
            // заказыBindingSource
            // 
            this.заказыBindingSource.DataMember = "Заказы";
            this.заказыBindingSource.DataSource = this.____Тихонова_4_курс_практикаDataSet2;
            // 
            // ____Тихонова_4_курс_практикаDataSet2
            // 
            this.____Тихонова_4_курс_практикаDataSet2.DataSetName = "____Тихонова_4_курс_практикаDataSet2";
            this.____Тихонова_4_курс_практикаDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox11);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Location = new System.Drawing.Point(791, 181);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(238, 73);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Поиск по номеру заказа";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(6, 32);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 25);
            this.textBox11.TabIndex = 26;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.YellowGreen;
            this.button9.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button9.Location = new System.Drawing.Point(130, 30);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(35, 28);
            this.button9.TabIndex = 27;
            this.button9.Text = "L";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox21);
            this.panel2.Controls.Add(this.textBox22);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.textBox23);
            this.panel2.Controls.Add(this.textBox28);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.textBox7);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Controls.Add(this.textBox9);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(17, 181);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(749, 205);
            this.panel2.TabIndex = 25;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(507, 123);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(159, 25);
            this.textBox21.TabIndex = 45;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(507, 89);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(159, 25);
            this.textBox22.TabIndex = 44;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(353, 123);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(151, 18);
            this.label21.TabIndex = 42;
            this.label21.Text = "Номер поставщика";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.YellowGreen;
            this.button3.Location = new System.Drawing.Point(574, 159);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(92, 23);
            this.button3.TabIndex = 24;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.YellowGreen;
            this.button5.Location = new System.Drawing.Point(466, 160);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(92, 23);
            this.button5.TabIndex = 23;
            this.button5.Text = "Изменить";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.YellowGreen;
            this.button6.Location = new System.Drawing.Point(356, 160);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(92, 23);
            this.button6.TabIndex = 22;
            this.button6.Text = "Добавить";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(353, 89);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(145, 18);
            this.label22.TabIndex = 41;
            this.label22.Text = "Номер менеджера";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(507, 52);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(159, 25);
            this.textBox23.TabIndex = 40;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(507, 18);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(159, 25);
            this.textBox28.TabIndex = 39;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(353, 53);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(116, 18);
            this.label27.TabIndex = 38;
            this.label27.Text = "Статус заказа";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(353, 18);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(127, 18);
            this.label28.TabIndex = 37;
            this.label28.Text = "Сроки поставки";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(162, 157);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(159, 25);
            this.textBox7.TabIndex = 36;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 160);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(154, 18);
            this.label12.TabIndex = 35;
            this.label12.Text = "Количество товара";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(162, 121);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(159, 25);
            this.textBox8.TabIndex = 34;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(162, 87);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(159, 25);
            this.textBox9.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 142);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 18);
            this.label13.TabIndex = 32;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 121);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(138, 18);
            this.label14.TabIndex = 31;
            this.label14.Text = "Название товара";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 87);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(141, 18);
            this.label15.TabIndex = 30;
            this.label15.Text = "Дата добавления";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(162, 50);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(159, 25);
            this.textBox1.TabIndex = 12;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(162, 16);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(159, 25);
            this.textBox4.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 18);
            this.label7.TabIndex = 1;
            this.label7.Text = "Номер клиента";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 18);
            this.label8.TabIndex = 0;
            this.label8.Text = "Номер заказа";
            // 
            // маршрут2BindingSource1
            // 
            this.маршрут2BindingSource1.DataMember = "маршрут2";
            this.маршрут2BindingSource1.DataSource = this.____Tihonova_TuristichClubDataSet10;
            // 
            // ____Tihonova_TuristichClubDataSet10
            // 
            this.____Tihonova_TuristichClubDataSet10.DataSetName = "____Tihonova_TuristichClubDataSet10";
            this.____Tihonova_TuristichClubDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // маршрутBindingSource
            // 
            this.маршрутBindingSource.DataMember = "маршрут";
            this.маршрутBindingSource.DataSource = this.____Tihonova_TuristichClubDataSet3;
            // 
            // ____Tihonova_TuristichClubDataSet3
            // 
            this.____Tihonova_TuristichClubDataSet3.DataSetName = "____Tihonova_TuristichClubDataSet3";
            this.____Tihonova_TuristichClubDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Green;
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1047, 400);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Товары";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Location = new System.Drawing.Point(751, 18);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(238, 100);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Поиск по названию товара";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(6, 43);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 25);
            this.textBox10.TabIndex = 26;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.YellowGreen;
            this.button7.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button7.Location = new System.Drawing.Point(127, 43);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(35, 28);
            this.button7.TabIndex = 27;
            this.button7.Text = "L";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.названиетовараDataGridViewTextBoxColumn,
            this.полноеназваниеDataGridViewTextBoxColumn,
            this.условиясодержанияDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.товарыBindingSource;
            this.dataGridView1.Enabled = false;
            this.dataGridView1.Location = new System.Drawing.Point(16, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(407, 363);
            this.dataGridView1.TabIndex = 0;
            // 
            // названиетовараDataGridViewTextBoxColumn
            // 
            this.названиетовараDataGridViewTextBoxColumn.DataPropertyName = "Название_товара";
            this.названиетовараDataGridViewTextBoxColumn.HeaderText = "Название_товара";
            this.названиетовараDataGridViewTextBoxColumn.Name = "названиетовараDataGridViewTextBoxColumn";
            // 
            // полноеназваниеDataGridViewTextBoxColumn
            // 
            this.полноеназваниеDataGridViewTextBoxColumn.DataPropertyName = "Полное_название";
            this.полноеназваниеDataGridViewTextBoxColumn.HeaderText = "Полное_название";
            this.полноеназваниеDataGridViewTextBoxColumn.Name = "полноеназваниеDataGridViewTextBoxColumn";
            // 
            // условиясодержанияDataGridViewTextBoxColumn
            // 
            this.условиясодержанияDataGridViewTextBoxColumn.DataPropertyName = "Условия_содержания";
            this.условиясодержанияDataGridViewTextBoxColumn.HeaderText = "Условия_содержания";
            this.условиясодержанияDataGridViewTextBoxColumn.Name = "условиясодержанияDataGridViewTextBoxColumn";
            // 
            // товарыBindingSource
            // 
            this.товарыBindingSource.DataMember = "Товары";
            this.товарыBindingSource.DataSource = this.____Тихонова_4_курс_практикаDataSet1;
            // 
            // ____Тихонова_4_курс_практикаDataSet1
            // 
            this.____Тихонова_4_курс_практикаDataSet1.DataSetName = "____Тихонова_4_курс_практикаDataSet1";
            this.____Тихонова_4_курс_практикаDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(455, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(267, 363);
            this.panel1.TabIndex = 13;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(42, 215);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(159, 25);
            this.textBox5.TabIndex = 26;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(39, 178);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(166, 18);
            this.label20.TabIndex = 25;
            this.label20.Text = "Условия содержания";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.YellowGreen;
            this.button2.Location = new System.Drawing.Point(77, 333);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(92, 23);
            this.button2.TabIndex = 24;
            this.button2.Text = "Удалить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.YellowGreen;
            this.button1.Location = new System.Drawing.Point(77, 294);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "Изменить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.YellowGreen;
            this.button4.Location = new System.Drawing.Point(77, 256);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(92, 23);
            this.button4.TabIndex = 22;
            this.button4.Text = "Добавить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(42, 138);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(159, 25);
            this.textBox3.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(42, 53);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(159, 25);
            this.textBox2.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 18);
            this.label3.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 18);
            this.label5.TabIndex = 1;
            this.label5.Text = "Полное название";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 18);
            this.label6.TabIndex = 0;
            this.label6.Text = "Название товара";
            // 
            // уровеньсложностиBindingSource
            // 
            this.уровеньсложностиBindingSource.DataMember = "уровень_сложности";
            this.уровеньсложностиBindingSource.DataSource = this.____Tihonova_TuristichClubDataSet2;
            // 
            // ____Tihonova_TuristichClubDataSet2
            // 
            this.____Tihonova_TuristichClubDataSet2.DataSetName = "____Tihonova_TuristichClubDataSet2";
            this.____Tihonova_TuristichClubDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(-4, -2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1055, 431);
            this.tabControl1.TabIndex = 27;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.MediumPurple;
            this.tabPage6.Controls.Add(this.panel6);
            this.tabPage6.Controls.Add(this.groupBox4);
            this.tabPage6.Controls.Add(this.dataGridView6);
            this.tabPage6.Location = new System.Drawing.Point(4, 27);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1047, 400);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Пользователи";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.textBox32);
            this.panel6.Controls.Add(this.label32);
            this.panel6.Controls.Add(this.button10);
            this.panel6.Controls.Add(this.textBox30);
            this.panel6.Controls.Add(this.button11);
            this.panel6.Controls.Add(this.label31);
            this.panel6.Controls.Add(this.button16);
            this.panel6.Controls.Add(this.textBox33);
            this.panel6.Controls.Add(this.label29);
            this.panel6.Location = new System.Drawing.Point(451, 177);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(583, 160);
            this.panel6.TabIndex = 49;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(209, 68);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(159, 25);
            this.textBox32.TabIndex = 37;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(37, 34);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(52, 18);
            this.label32.TabIndex = 34;
            this.label32.Text = "Логин";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.BlueViolet;
            this.button10.Location = new System.Drawing.Point(416, 111);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(92, 23);
            this.button10.TabIndex = 40;
            this.button10.Text = "Удалить";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(209, 106);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(159, 25);
            this.textBox30.TabIndex = 44;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.BlueViolet;
            this.button11.Location = new System.Drawing.Point(416, 72);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(92, 23);
            this.button11.TabIndex = 39;
            this.button11.Text = "Изменить";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(37, 71);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(63, 18);
            this.label31.TabIndex = 35;
            this.label31.Text = "Пароль";
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.BlueViolet;
            this.button16.Location = new System.Drawing.Point(416, 32);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(92, 23);
            this.button16.TabIndex = 38;
            this.button16.Text = "Добавить";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(209, 34);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(159, 25);
            this.textBox33.TabIndex = 36;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(37, 106);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(43, 18);
            this.label29.TabIndex = 42;
            this.label29.Text = "роль";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox34);
            this.groupBox4.Controls.Add(this.button26);
            this.groupBox4.Location = new System.Drawing.Point(451, 30);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(583, 100);
            this.groupBox4.TabIndex = 47;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Найти по логину";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(6, 42);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 25);
            this.textBox34.TabIndex = 45;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.BlueViolet;
            this.button26.Font = new System.Drawing.Font("Webdings", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button26.Location = new System.Drawing.Point(127, 42);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(35, 28);
            this.button26.TabIndex = 46;
            this.button26.Text = "L";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // dataGridView6
            // 
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.логинDataGridViewTextBoxColumn,
            this.парольDataGridViewTextBoxColumn,
            this.рольDataGridViewTextBoxColumn});
            this.dataGridView6.DataSource = this.пользователиBindingSource2;
            this.dataGridView6.Enabled = false;
            this.dataGridView6.Location = new System.Drawing.Point(37, 30);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(398, 307);
            this.dataGridView6.TabIndex = 33;
            // 
            // логинDataGridViewTextBoxColumn
            // 
            this.логинDataGridViewTextBoxColumn.DataPropertyName = "Логин";
            this.логинDataGridViewTextBoxColumn.HeaderText = "Логин";
            this.логинDataGridViewTextBoxColumn.Name = "логинDataGridViewTextBoxColumn";
            // 
            // парольDataGridViewTextBoxColumn
            // 
            this.парольDataGridViewTextBoxColumn.DataPropertyName = "Пароль";
            this.парольDataGridViewTextBoxColumn.HeaderText = "Пароль";
            this.парольDataGridViewTextBoxColumn.Name = "парольDataGridViewTextBoxColumn";
            // 
            // рольDataGridViewTextBoxColumn
            // 
            this.рольDataGridViewTextBoxColumn.DataPropertyName = "Роль";
            this.рольDataGridViewTextBoxColumn.HeaderText = "Роль";
            this.рольDataGridViewTextBoxColumn.Name = "рольDataGridViewTextBoxColumn";
            // 
            // пользователиBindingSource2
            // 
            this.пользователиBindingSource2.DataMember = "Пользователи";
            this.пользователиBindingSource2.DataSource = this.____Тихонова_4_курс_практикаDataSet7;
            // 
            // ____Тихонова_4_курс_практикаDataSet7
            // 
            this.____Тихонова_4_курс_практикаDataSet7.DataSetName = "____Тихонова_4_курс_практикаDataSet7";
            this.____Тихонова_4_курс_практикаDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // пользователиBindingSource1
            // 
            this.пользователиBindingSource1.DataMember = "Пользователи";
            this.пользователиBindingSource1.DataSource = this.____Тихонова_4_курс_практикаDataSet6;
            // 
            // ____Тихонова_4_курс_практикаDataSet6
            // 
            this.____Тихонова_4_курс_практикаDataSet6.DataSetName = "____Тихонова_4_курс_практикаDataSet6";
            this.____Тихонова_4_курс_практикаDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // уровень_сложностиTableAdapter
            // 
            this.уровень_сложностиTableAdapter.ClearBeforeFill = true;
            // 
            // маршрутTableAdapter
            // 
            this.маршрутTableAdapter.ClearBeforeFill = true;
            // 
            // пункт_назначенияTableAdapter
            // 
            this.пункт_назначенияTableAdapter.ClearBeforeFill = true;
            // 
            // оплатаTableAdapter
            // 
            this.оплатаTableAdapter.ClearBeforeFill = true;
            // 
            // пользователиTableAdapter
            // 
            this.пользователиTableAdapter.ClearBeforeFill = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // ____Tihonova_TuristichClubDataSet9
            // 
            this.____Tihonova_TuristichClubDataSet9.DataSetName = "____Tihonova_TuristichClubDataSet9";
            this.____Tihonova_TuristichClubDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // маршрут2BindingSource
            // 
            this.маршрут2BindingSource.DataMember = "маршрут2";
            this.маршрут2BindingSource.DataSource = this.____Tihonova_TuristichClubDataSet9;
            // 
            // маршрут2TableAdapter
            // 
            this.маршрут2TableAdapter.ClearBeforeFill = true;
            // 
            // маршрут2TableAdapter1
            // 
            this.маршрут2TableAdapter1.ClearBeforeFill = true;
            // 
            // товарыTableAdapter
            // 
            this.товарыTableAdapter.ClearBeforeFill = true;
            // 
            // заказыTableAdapter
            // 
            this.заказыTableAdapter.ClearBeforeFill = true;
            // 
            // поставщикиTableAdapter
            // 
            this.поставщикиTableAdapter.ClearBeforeFill = true;
            // 
            // менеджерыTableAdapter
            // 
            this.менеджерыTableAdapter.ClearBeforeFill = true;
            // 
            // клиентыTableAdapter
            // 
            this.клиентыTableAdapter.ClearBeforeFill = true;
            // 
            // пользователиTableAdapter1
            // 
            this.пользователиTableAdapter1.ClearBeforeFill = true;
            // 
            // пользователиTableAdapter2
            // 
            this.пользователиTableAdapter2.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(1046, 422);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form1";
            this.Text = "База данных";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabPage5.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet5)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet6)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.менеджерыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet4)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.оплатаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet5)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.поставщикиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet3)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пунктназначенияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet4)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.маршрут2BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маршрутBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet3)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.уровеньсложностиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.маршрут2BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
  

        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private ____Tihonova_TuristichClubDataSet2 ____Tihonova_TuristichClubDataSet2;
        private System.Windows.Forms.BindingSource уровеньсложностиBindingSource;
        private ____Tihonova_TuristichClubDataSet2TableAdapters.уровень_сложностиTableAdapter уровень_сложностиTableAdapter;
        private ____Tihonova_TuristichClubDataSet3 ____Tihonova_TuristichClubDataSet3;
        private System.Windows.Forms.BindingSource маршрутBindingSource;
        private ____Tihonova_TuristichClubDataSet3TableAdapters.маршрутTableAdapter маршрутTableAdapter;
        private ____Tihonova_TuristichClubDataSet4 ____Tihonova_TuristichClubDataSet4;
        private System.Windows.Forms.BindingSource пунктназначенияBindingSource;
        private ____Tihonova_TuristichClubDataSet4TableAdapters.пункт_назначенияTableAdapter пункт_назначенияTableAdapter;
        private ____Tihonova_TuristichClubDataSet5 ____Tihonova_TuristichClubDataSet5;
        private System.Windows.Forms.BindingSource оплатаBindingSource;
        private ____Tihonova_TuristichClubDataSet5TableAdapters.оплатаTableAdapter оплатаTableAdapter;
        private ____Tihonova_TuristichClubDataSet6 ____Tihonova_TuristichClubDataSet6;
        private System.Windows.Forms.BindingSource пользователиBindingSource;
        private ____Tihonova_TuristichClubDataSet6TableAdapters.пользователиTableAdapter пользователиTableAdapter;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private ____Tihonova_TuristichClubDataSet9 ____Tihonova_TuristichClubDataSet9;
        private System.Windows.Forms.BindingSource маршрут2BindingSource;
        private ____Tihonova_TuristichClubDataSet9TableAdapters.маршрут2TableAdapter маршрут2TableAdapter;
        private System.Windows.Forms.DataGridView dataGridView3;
        private ____Tihonova_TuristichClubDataSet10 ____Tihonova_TuristichClubDataSet10;
        private System.Windows.Forms.BindingSource маршрут2BindingSource1;
        private ____Tihonova_TuristichClubDataSet10TableAdapters.маршрут2TableAdapter маршрут2TableAdapter1;
        private ____Тихонова_4_курс_практикаDataSet1 ____Тихонова_4_курс_практикаDataSet1;
        private System.Windows.Forms.BindingSource товарыBindingSource;
        private ____Тихонова_4_курс_практикаDataSet1TableAdapters.ТоварыTableAdapter товарыTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиетовараDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn полноеназваниеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn условиясодержанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label20;
        private ____Тихонова_4_курс_практикаDataSet2 ____Тихонова_4_курс_практикаDataSet2;
        private System.Windows.Forms.BindingSource заказыBindingSource;
        private ____Тихонова_4_курс_практикаDataSet2TableAdapters.ЗаказыTableAdapter заказыTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерклиентаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датадобавленияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиетовараDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествотовараDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn срокипоставкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn статусзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерменеджераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерпоставщикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button8;
        private ____Тихонова_4_курс_практикаDataSet3 ____Тихонова_4_курс_практикаDataSet3;
        private System.Windows.Forms.BindingSource поставщикиBindingSource;
        private ____Тихонова_4_курс_практикаDataSet3TableAdapters.ПоставщикиTableAdapter поставщикиTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерпоставщикаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяпоставщикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номеравтомобиляDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label1;
        private ____Тихонова_4_курс_практикаDataSet4 ____Тихонова_4_курс_практикаDataSet4;
        private System.Windows.Forms.BindingSource менеджерыBindingSource;
        private ____Тихонова_4_курс_практикаDataSet4TableAdapters.МенеджерыTableAdapter менеджерыTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерменеджераDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn логинменеджераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяменеджераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn окладDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаприеманаработуDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label11;
        private ____Тихонова_4_курс_практикаDataSet5 ____Тихонова_4_курс_практикаDataSet5;
        private System.Windows.Forms.BindingSource клиентыBindingSource;
        private ____Тихонова_4_курс_практикаDataSet5TableAdapters.КлиентыTableAdapter клиентыTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерклиентаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn логинклиентаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn телефонDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.DataGridView dataGridView6;
        private ____Тихонова_4_курс_практикаDataSet6 ____Тихонова_4_курс_практикаDataSet6;
        private System.Windows.Forms.BindingSource пользователиBindingSource1;
        private ____Тихонова_4_курс_практикаDataSet6TableAdapters.ПользователиTableAdapter пользователиTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn логинDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn парольDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn рольDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label8;
        private ____Тихонова_4_курс_практикаDataSet7 ____Тихонова_4_курс_практикаDataSet7;
        private System.Windows.Forms.BindingSource пользователиBindingSource2;
        private ____Тихонова_4_курс_практикаDataSet7TableAdapters.ПользователиTableAdapter пользователиTableAdapter2;
    }
}

