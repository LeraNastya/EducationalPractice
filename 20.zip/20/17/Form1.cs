﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _17
{
    public partial class Form1 : Form
    {
        Form2 form2;
        public int a = 2;
        string str = "";
        //public bool Admin = form2.ADMIN;

        public Form1()
        {
            InitializeComponent();
        }
        //bool admf = true;
        public void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet7.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter2.Fill(this.____Тихонова_4_курс_практикаDataSet7.Пользователи);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet5.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet5.Клиенты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet4.Менеджеры". При необходимости она может быть перемещена или удалена.
            this.менеджерыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet4.Менеджеры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet3.Поставщики". При необходимости она может быть перемещена или удалена.
            this.поставщикиTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet3.Поставщики);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet2.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet2.Заказы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet1.Товары". При необходимости она может быть перемещена или удалена.
            this.товарыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet1.Товары);

            form2 = (Form2)this.Owner;
                a = form2.ADMIN;
            if (a==0)
            {
                panel1.Visible = true;
                panel2.Visible = true;
                panel3.Visible = true;
                panel4.Visible = true;
                panel5.Visible = true;
                panel6.Visible = true;
            }
            else if (a == 1)
            {
                panel1.Visible = true;
                panel2.Visible = true;
                panel3.Visible = false;
                panel4.Visible = true;
                panel5.Visible = false;
                panel6.Visible = false;

                tabPage5.Parent = null;
                tabPage6.Parent = null;
            }
            else
            {
                panel1.Visible = false;
                panel2.Visible = true;

                textBox28.Visible = false;
                textBox23.Visible = false;
                textBox22.Visible = false;
                textBox21.Visible = false;

                panel3.Visible = false;
                panel4.Visible = false;
                panel5.Visible = false;
                panel6.Visible = false;

                tabPage3.Parent = null;
                tabPage4.Parent = null;
                tabPage5.Parent = null;
                tabPage6.Parent = null;
            }
        }

        private void button4_Click(object sender, EventArgs e) //добавить 1 стр
        {
            string name = Convert.ToString(textBox2.Text);
            string fullname = Convert.ToString(textBox3.Text);
            string yslovie = Convert.ToString(textBox5.Text);

            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Товары([Название_товара],[Полное_название],[Условия_содержания]) VALUES(@name,@fullname,@yslovie);";

            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@fullname", fullname);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@yslovie", yslovie);

            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet1.Товары". При необходимости она может быть перемещена или удалена.
            this.товарыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet1.Товары);
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
        }

        private void button1_Click(object sender, EventArgs e) // изменить 1 стр
        {
            string name = Convert.ToString(textBox2.Text);
            string fullname = Convert.ToString(textBox3.Text);
            string yslovie = Convert.ToString(textBox5.Text);

            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Update Товары set [Полное_название]=@fullname, [Условия_содержания]=@yslovie where [Название_товара]=@name;";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@fullname", fullname);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@yslovie", yslovie);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet1.Товары". При необходимости она может быть перемещена или удалена.
            this.товарыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet1.Товары);
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
        }

        private void button2_Click(object sender, EventArgs e) //удаление для первой таблицы
        {
            
            string yslovie = Convert.ToString(textBox2.Text);
            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = "Delete from Товары where [Название_товара]=@yslovie";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@yslovie", yslovie);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet1.Товары". При необходимости она может быть перемещена или удалена.
            this.товарыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet1.Товары);
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
        }

        private void button6_Click(object sender, EventArgs e) //добавить для второй таблицы
        {
            string numberClient = textBox1.Text;
            string date = textBox9.Text;
            string name = textBox8.Text;
            string count = textBox7.Text;
            string time = textBox28.Text;
            string status = textBox23.Text;
            string numberMeneger = textBox22.Text;
            string numberPost = textBox21.Text;

            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Заказы([Номер_клиента],[Дата_добавления],[Название_товара],[Количество_товара],[Сроки_поставки],[Статус_заказа],[Номер_менеджера],[Номер_поставщика]) VALUES(@numberClient,@date,@name,@count,@time,@status,@numberMeneger,@numberPost);";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);           
            cmd1.Parameters.AddWithValue("@numberClient", numberClient);
            cmd1.Parameters.AddWithValue("@date", date);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@count", count);
            cmd1.Parameters.AddWithValue("@time", time);
            cmd1.Parameters.AddWithValue("@status", status);
            cmd1.Parameters.AddWithValue("@numberMeneger", numberMeneger);
            cmd1.Parameters.AddWithValue("@numberPost", numberPost);

            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet2.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet2.Заказы);

            textBox4.Clear();
            textBox1.Clear();
            textBox9.Clear();
            textBox8.Clear();
            textBox7.Clear();
            textBox28.Clear();
            textBox23.Clear();
            textBox22.Clear();
            textBox21.Clear();
        }

        private void button5_Click(object sender, EventArgs e) //изменить для второй таблицы
        {
            string numberZakaz = textBox4.Text;
            string numberClient = textBox1.Text;
            string date = textBox9.Text;
            string name = textBox8.Text;
            string count = textBox7.Text;
            string time = textBox28.Text;
            string status = textBox23.Text;
            string numberMeneger = textBox22.Text;
            string numberPost = textBox21.Text;

            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Update Заказы set [Номер_клиента]=@numberClient,[Дата_добавления]=@date,[Название_товара]=@name,[Количество_товара]=@count,[Сроки_поставки]=@time,[Статус_заказа]=@status,[Номер_менеджера]=@numberMeneger,[Номер_поставщика]=@numberPost where [Номер_заказа]=@numberZakaz;";

            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@numberZakaz", numberZakaz);
            cmd1.Parameters.AddWithValue("@numberClient", numberClient);
            cmd1.Parameters.AddWithValue("@date", date);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@count", count);
            cmd1.Parameters.AddWithValue("@time", time);
            cmd1.Parameters.AddWithValue("@status", status);
            cmd1.Parameters.AddWithValue("@numberMeneger", numberMeneger);
            cmd1.Parameters.AddWithValue("@numberPost", numberPost);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();


            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet2.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet2.Заказы);

            textBox4.Clear();
            textBox1.Clear();
            textBox9.Clear();
            textBox8.Clear();
            textBox7.Clear();
            textBox28.Clear();
            textBox23.Clear();
            textBox22.Clear();
            textBox21.Clear();
        }

        private void button3_Click(object sender, EventArgs e) //удалить для второй таблицы
        {
            int a = Convert.ToInt32(textBox4.Text);
            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = " Delete from Заказы where [Номер_заказа]=@a";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@a", a);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet2.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet2.Заказы);

            textBox4.Clear();
            textBox1.Clear();
            textBox9.Clear();
            textBox8.Clear();
            textBox7.Clear();
            textBox28.Clear();
            textBox23.Clear();
            textBox22.Clear();
            textBox21.Clear();
        }

        private void button7_Click(object sender, EventArgs e) // поиск для первой таблицы
        {
            dataGridView1.ClearSelection();
            string searchValue = textBox10.Text;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            dataGridView1.Refresh();
            textBox10.Clear();            
        }
      
        private void button9_Click(object sender, EventArgs e) //поиск для второй
        {
            dataGridView3.ClearSelection();
            string searchValue = textBox11.Text;
            dataGridView3.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView3.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            dataGridView3.Refresh();
            textBox11.Clear();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            label10.Text = dataGridView3.RowCount.ToString();
        }

        //////////////////////// ТРЕТЬЯ ТАБЛИЦА
        private void button20_Click(object sender, EventArgs e) // добавить
        {
            string number = Convert.ToString(textBox14.Text);
            string name = Convert.ToString(textBox15.Text);
            string car = Convert.ToString(textBox6.Text);

            string connectionString = @" Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Поставщики([Номер_поставщика],[Имя_поставщика],[Номер_автомобиля]) VALUES(@number,@name,@car);";

            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@number", number);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@car", car);

            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet3.Поставщики". При необходимости она может быть перемещена или удалена.
            this.поставщикиTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet3.Поставщики);

            textBox14.Clear();
            textBox15.Clear();
            textBox6.Clear();
        }

        private void button19_Click(object sender, EventArgs e) //изменить
        {
            string number = Convert.ToString(textBox14.Text);
            string name = Convert.ToString(textBox15.Text);
            string car = Convert.ToString(textBox6.Text);

            string connectionString = @" Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Update Поставщики set [Имя_поставщика]=@name,[Номер_автомобиля]=@car where [Номер_поставщика]=@number;";

            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@number", number);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@car", car);

            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet3.Поставщики". При необходимости она может быть перемещена или удалена.
            this.поставщикиTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet3.Поставщики);

            textBox14.Clear();
            textBox15.Clear();
            textBox6.Clear();
        }

        private void button18_Click(object sender, EventArgs e) //удалить
        {
            string number = Convert.ToString(textBox14.Text);
            string connectionString = @" Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = "Delete from Поставщики where [Номер_поставщика]=@number";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@number", number);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet3.Поставщики". При необходимости она может быть перемещена или удалена.
            this.поставщикиTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet3.Поставщики);

            textBox14.Clear();
            textBox15.Clear();
            textBox6.Clear();
        }

        private void button17_Click(object sender, EventArgs e) //поиск
        {
            dataGridView4.ClearSelection();
            string searchValue = textBox13.Text;
            dataGridView4.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView4.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            dataGridView4.Refresh();
            textBox13.Clear();
        }

        //////////////////////////////// ТАБЛИЦА 4
        private void button15_Click(object sender, EventArgs e) //добавить
        {
            //string num = Convert.ToString(textBox19.Text);
            string login = Convert.ToString(textBox18.Text);
            string name = Convert.ToString(textBox17.Text);
            string ocl = Convert.ToString(textBox16.Text);
            string time = Convert.ToString(textBox29.Text);

            string connectionString = @" Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Менеджеры([Логин_менеджера],[Имя_менеджера],[Оклад],[Дата_приема_на_работу]) VALUES(@login,@name,@ocl,@time);";

            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            //cmd1.Parameters.AddWithValue("@num", num);
            cmd1.Parameters.AddWithValue("@login", login);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@ocl", ocl);
            cmd1.Parameters.AddWithValue("@time", time);

            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet4.Менеджеры". При необходимости она может быть перемещена или удалена.
            this.менеджерыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet4.Менеджеры);

            textBox19.Clear();
            textBox18.Clear();
            textBox17.Clear();
            textBox16.Clear();
            textBox29.Clear();
        }

        private void button14_Click(object sender, EventArgs e) //изменить
        {
            string num = Convert.ToString(textBox19.Text);
            string login = Convert.ToString(textBox18.Text);
            string name = Convert.ToString(textBox17.Text);
            string ocl = Convert.ToString(textBox16.Text);
            string time = Convert.ToString(textBox29.Text);

            string connectionString = @" Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Update Менеджеры set [Логин_менеджера]=@login,[Имя_менеджера]=@name,[Оклад]=@ocl,[Дата_приема_на_работу]=@time where [Номер_менеджера]=@num;";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@num", num);
            cmd1.Parameters.AddWithValue("@login", login);
            cmd1.Parameters.AddWithValue("@name", name);
            cmd1.Parameters.AddWithValue("@ocl", ocl);
            cmd1.Parameters.AddWithValue("@time", time);

            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet4.Менеджеры". При необходимости она может быть перемещена или удалена.
            this.менеджерыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet4.Менеджеры);

            textBox19.Clear();
            textBox18.Clear();
            textBox17.Clear();
            textBox16.Clear();
            textBox29.Clear();
        }

        private void button13_Click(object sender, EventArgs e) //удалить
        {
            string num = Convert.ToString(textBox19.Text);
            string connectionString = @" Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = "Delete from Менеджеры where [Номер_менеджера]=@num";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@num", num);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet4.Менеджеры". При необходимости она может быть перемещена или удалена.
            this.менеджерыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet4.Менеджеры);

            textBox19.Clear();
            textBox18.Clear();
            textBox17.Clear();
            textBox16.Clear();
            textBox29.Clear();
        }

        private void button12_Click(object sender, EventArgs e) //поиск
        {
            dataGridView2.ClearSelection();
            string searchValue = textBox12.Text;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView2.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            dataGridView2.Refresh();
            textBox12.Clear();
        }

        ////////////////////////// ТАБЛИЦА 5
        private void button25_Click(object sender, EventArgs e) //добавить
        {
            string log = Convert.ToString(textBox26.Text);
            string tel = Convert.ToString(textBox25.Text);

            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Клиенты([Логин_клиента],[Телефон]) VALUES(@log,@tel);";

            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@log", log);
            cmd1.Parameters.AddWithValue("@tel", tel);


            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet5.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet5.Клиенты);

            textBox27.Clear();
            textBox26.Clear();
            textBox25.Clear();

        }

        private void button24_Click(object sender, EventArgs e) //изменить
        {
            string num = Convert.ToString(textBox27.Text);
            string log = Convert.ToString(textBox26.Text);
            string tel = Convert.ToString(textBox25.Text);

            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Update Клиенты set [Логин_клиента]=@log,[Телефон]=@tel where [Номер_клиента]=@num;";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@num", num);
            cmd1.Parameters.AddWithValue("@log", log);
            cmd1.Parameters.AddWithValue("@tel", tel);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet5.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet5.Клиенты);

            textBox27.Clear();
            textBox26.Clear();
            textBox25.Clear();
        }

        private void button23_Click(object sender, EventArgs e) //удалить
        {
            string num = Convert.ToString(textBox27.Text);
            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = "Delete from Клиенты where [Номер_клиента]=@num";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@num", num);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet5.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.____Тихонова_4_курс_практикаDataSet5.Клиенты);

            textBox27.Clear();
            textBox26.Clear();
            textBox25.Clear();
        }

        private void button22_Click(object sender, EventArgs e) //поиск
        {
            dataGridView5.ClearSelection();
            string searchValue = textBox20.Text;
            dataGridView5.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView5.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            dataGridView5.Refresh();
            textBox20.Clear();
        }

        private void button21_Click(object sender, EventArgs e) //сортировка
        {
            if (radioButton10.Checked)
            {
                if (comboBox5.Text == "Номер")
                {
                    dataGridView5.Sort(dataGridView5.Columns[0], ListSortDirection.Descending);

                }
                else if (comboBox5.Text == "Логин")
                {
                    dataGridView5.Sort(dataGridView5.Columns[1], ListSortDirection.Descending);
                }
                else if (comboBox5.Text == "Телефон")
                {
                    dataGridView5.Sort(dataGridView5.Columns[2], ListSortDirection.Descending);

                }
            }
            else if (radioButton9.Checked)
            {
                if (comboBox5.Text == "Номер")
                {
                    dataGridView5.Sort(dataGridView5.Columns[0], ListSortDirection.Ascending);

                }
                else if (comboBox5.Text == "Логин")
                {
                    dataGridView5.Sort(dataGridView5.Columns[1], ListSortDirection.Ascending);
                }
                else if (comboBox5.Text == "Телефон")
                {
                    dataGridView5.Sort(dataGridView5.Columns[2], ListSortDirection.Ascending);

                }
            }
        }

        ////////////////////////// ТАБЛИЦА 6
        private void button16_Click(object sender, EventArgs e) //добавить
        {
            string login = Convert.ToString(textBox33.Text);
            string parol = Convert.ToString(textBox32.Text);
            string rol = Convert.ToString(textBox30.Text);

            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Insert into Пользователи([Логин],[Пароль],[Роль]) VALUES(@login,@parol,@rol);";

            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@login", login);
            cmd1.Parameters.AddWithValue("@parol", parol);
            cmd1.Parameters.AddWithValue("@rol", rol);

            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet7.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter2.Fill(this.____Тихонова_4_курс_практикаDataSet7.Пользователи);

            textBox33.Clear();
            textBox32.Clear();
            textBox30.Clear();
        }

        private void button11_Click(object sender, EventArgs e) //изменить
        {
            string login = Convert.ToString(textBox33.Text);
            string parol = Convert.ToString(textBox32.Text);
            string rol = Convert.ToString(textBox30.Text);

            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = $"Update Пользователи set [Пароль]=@parol,[Роль]=@rol where [Логин]=@login;";

            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@login", login);
            cmd1.Parameters.AddWithValue("@parol", parol);
            cmd1.Parameters.AddWithValue("@rol", rol);

            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet7.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter2.Fill(this.____Тихонова_4_курс_практикаDataSet7.Пользователи);

            textBox33.Clear();
            textBox32.Clear();
            textBox30.Clear();
        }

        private void button10_Click(object sender, EventArgs e) //удалить
        {
            string log = Convert.ToString(textBox33.Text);
            string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
            SqlConnection MyConnection = new SqlConnection(connectionString);
            string ComDel = "Delete from Пользователи where [Логин]=@log";
            SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
            cmd1.Parameters.AddWithValue("@log", log);
            MyConnection.Open();
            cmd1.ExecuteNonQuery();
            MyConnection.Close();

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet7.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter2.Fill(this.____Тихонова_4_курс_практикаDataSet7.Пользователи);

            textBox33.Clear();
            textBox32.Clear();
            textBox30.Clear();
        }

        private void button26_Click(object sender, EventArgs e) //поиск
        {
            dataGridView6.ClearSelection();
            string searchValue = textBox34.Text;
            dataGridView6.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                foreach (DataGridViewRow row in dataGridView6.Rows)
                {
                    if (row.Cells[0].Value.ToString().TrimEnd() == searchValue)
                    {
                        row.Selected = true;
                        break;
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            dataGridView6.Refresh();
            textBox34.Clear();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
