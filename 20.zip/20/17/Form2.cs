﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _17
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public int Admin;
        public int ADMIN
        {
            get { return Admin; }
            set { value = Admin; }
        }
        private void button1_Click(object sender, EventArgs e) //Вход
        {
            button3.Visible = false;
            textBox3.Visible = false;
            button3.Visible = false;

            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter4.Fill(this.____Тихонова_4_курс_практикаDataSet.Пользователи);
            try
            {
                string log = textBox1.Text;
                string pass =textBox2.Text;

                string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDel = "Select Логин from Пользователи where Логин='" + log + "'";
                SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                string ComDell = "Select Пароль from Пользователи where Пароль=" + pass+ " and Логин='" + log + "'";
                SqlCommand cmd2 = new SqlCommand(ComDell, MyConnection);
                string ComDelll = "Select Роль from Пользователи where Пароль=" + pass + " and Логин='" + log + "'";
                SqlCommand cmd3 = new SqlCommand(ComDelll, MyConnection);
                MyConnection.Open();
                string a = cmd1.ExecuteScalar().ToString().TrimEnd();
                string b = cmd2.ExecuteScalar().ToString().TrimEnd();
                string c = cmd3.ExecuteScalar().ToString().TrimEnd();
                if (a == log && b == pass)
                {   
                    Form1 form1 = new Form1();  // создание экземпляра первой формы
                    if (c == "администратор")
                        Admin = 0;
                    else if (c == "менеджер")
                        Admin = 1;
                    else Admin = 2;

                    form1.Owner = this;     // родительской для формы 2 будет текущая форма
                    form1.ShowDialog();     // показать окно второй формы в немодальном режиме    
                    this.Visible = false;
                    this.Enabled = false;
                }
                else { MessageBox.Show("Неправильный пароль!"); }
                MyConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Такого пользователя не существует. Пройдите регистрацию!");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter4.Fill(this.____Тихонова_4_курс_практикаDataSet.Пользователи);
        }

        private void button2_Click(object sender, EventArgs e) //кнопка регистрации
        {

            button3.Visible = true;
            button1.Visible = false;
            textBox3.Visible = true;
            button3.Visible = true;
            label3.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e) //кнопка добавить
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "____Тихонова_4_курс_практикаDataSet.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter4.Fill(this.____Тихонова_4_курс_практикаDataSet.Пользователи);
            try
            {
                string log = textBox1.Text;
                string pass = textBox2.Text;
                string tel = textBox3.Text;

                string role = "пользователь";
                string connectionString = @"Data Source= ADCLG1; Initial catalog=!!!Тихонова_4_курс_практика; Integrated Security=True";
                SqlConnection MyConnection = new SqlConnection(connectionString);
                string ComDell = "SELECT COUNT(*) FROM [Пользователи] where [Логин]=@log";
                SqlCommand cmd2 = new SqlCommand(ComDell, MyConnection);
                cmd2.Parameters.AddWithValue("@log", log);
                MyConnection.Open();
                int result = 0;
                result = ((int)cmd2.ExecuteScalar());
                //String b = cmd2.ExecuteScalar().ToString();
                if (result == 0 && log != "")
                {
                    string ComDel = $"Insert into Пользователи([Логин],[Пароль],[Роль]) VALUES(@log,@pass,@role);";
                    SqlCommand cmd1 = new SqlCommand(ComDel, MyConnection);
                    cmd1.Parameters.AddWithValue("@log", log);
                    cmd1.Parameters.AddWithValue("@pass", pass);
                    cmd1.Parameters.AddWithValue("@role", role);
                    cmd1.ExecuteNonQuery();

                    string ComDel2 = $"Insert into Клиенты([Логин_клиента],[Телефон]) VALUES(@log,@tel);";
                    SqlCommand cmd3 = new SqlCommand(ComDel2, MyConnection);
                    cmd3.Parameters.AddWithValue("@log", log);
                    cmd3.Parameters.AddWithValue("@tel", tel);
                    cmd3.ExecuteNonQuery();
                }
                else
                {
                    MessageBox.Show("Такой логин уже занят, выберите другое имя пользователя");
                    
                }
                MyConnection.Close();
            }
            catch
            {
                MessageBox.Show("Введите данные в поля");
            }

            label3.Visible = false;
            textBox3.Visible = false;
            button3.Visible = false;
            label3.Visible = false;
            button1.Visible = true;

            textBox1.Clear();
            textBox2.Clear();
        }

        private void button4_MouseUp(object sender, MouseEventArgs e)
        {
            button4.ForeColor = Color.Black;
            textBox2.PasswordChar = '*';
        }

        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            button4.ForeColor = Color.Red;
            textBox2.PasswordChar = '\0';
        }
    }
}
