﻿namespace _17
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.пользователиBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.____Tihonova_TuristichClubDataSet1 = new _17.____Tihonova_TuristichClubDataSet1();
            this.____Tihonova_TuristichClubDataSet = new _17.____Tihonova_TuristichClubDataSet();
            this.пользователиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.пользователиTableAdapter = new _17.____Tihonova_TuristichClubDataSetTableAdapters.пользователиTableAdapter();
            this.пользователиTableAdapter1 = new _17.____Tihonova_TuristichClubDataSet1TableAdapters.пользователиTableAdapter();
            this.____Tihonova_TuristichClubDataSet7 = new _17.____Tihonova_TuristichClubDataSet7();
            this.пользователиBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.пользователиTableAdapter2 = new _17.____Tihonova_TuristichClubDataSet7TableAdapters.пользователиTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.логинDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.парольDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.рольDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.пользователиBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.____Тихонова_4_курс_практикаDataSet = new _17.____Тихонова_4_курс_практикаDataSet();
            this.пользователиBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.____Tihonova_TuristichClubDataSet8 = new _17.____Tihonova_TuristichClubDataSet8();
            this.пользователиTableAdapter3 = new _17.____Tihonova_TuristichClubDataSet8TableAdapters.пользователиTableAdapter();
            this.пользователиTableAdapter4 = new _17.____Тихонова_4_курс_практикаDataSetTableAdapters.ПользователиTableAdapter();
            this.usersBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(83, 61);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введите логин:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(83, 120);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Введите пароль:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(243, 58);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(148, 28);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(243, 120);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(148, 25);
            this.textBox2.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.YellowGreen;
            this.button1.Location = new System.Drawing.Point(243, 229);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 36);
            this.button1.TabIndex = 4;
            this.button1.Text = "Вход";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.YellowGreen;
            this.button2.Location = new System.Drawing.Point(243, 277);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(148, 36);
            this.button2.TabIndex = 5;
            this.button2.Text = " Регистрация";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.YellowGreen;
            this.button3.Location = new System.Drawing.Point(243, 325);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(148, 36);
            this.button3.TabIndex = 9;
            this.button3.Text = " Добавить";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.YellowGreen;
            this.button4.Font = new System.Drawing.Font("Webdings", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.button4.Location = new System.Drawing.Point(411, 109);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(47, 46);
            this.button4.TabIndex = 10;
            this.button4.Text = "N";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button4_MouseDown);
            this.button4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button4_MouseUp);
            // 
            // пользователиBindingSource1
            // 
            this.пользователиBindingSource1.DataMember = "пользователи";
            this.пользователиBindingSource1.DataSource = this.____Tihonova_TuristichClubDataSet1;
            // 
            // ____Tihonova_TuristichClubDataSet1
            // 
            this.____Tihonova_TuristichClubDataSet1.DataSetName = "____Tihonova_TuristichClubDataSet1";
            this.____Tihonova_TuristichClubDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ____Tihonova_TuristichClubDataSet
            // 
            this.____Tihonova_TuristichClubDataSet.DataSetName = "____Tihonova_TuristichClubDataSet";
            this.____Tihonova_TuristichClubDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // пользователиBindingSource
            // 
            this.пользователиBindingSource.DataMember = "пользователи";
            this.пользователиBindingSource.DataSource = this.____Tihonova_TuristichClubDataSet;
            // 
            // пользователиTableAdapter
            // 
            this.пользователиTableAdapter.ClearBeforeFill = true;
            // 
            // пользователиTableAdapter1
            // 
            this.пользователиTableAdapter1.ClearBeforeFill = true;
            // 
            // ____Tihonova_TuristichClubDataSet7
            // 
            this.____Tihonova_TuristichClubDataSet7.DataSetName = "____Tihonova_TuristichClubDataSet7";
            this.____Tihonova_TuristichClubDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // пользователиBindingSource2
            // 
            this.пользователиBindingSource2.DataMember = "пользователи";
            this.пользователиBindingSource2.DataSource = this.____Tihonova_TuristichClubDataSet7;
            // 
            // пользователиTableAdapter2
            // 
            this.пользователиTableAdapter2.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.логинDataGridViewTextBoxColumn,
            this.парольDataGridViewTextBoxColumn,
            this.рольDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.пользователиBindingSource4;
            this.dataGridView1.Location = new System.Drawing.Point(133, 570);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(315, 64);
            this.dataGridView1.TabIndex = 11;
            // 
            // логинDataGridViewTextBoxColumn
            // 
            this.логинDataGridViewTextBoxColumn.DataPropertyName = "Логин";
            this.логинDataGridViewTextBoxColumn.HeaderText = "Логин";
            this.логинDataGridViewTextBoxColumn.Name = "логинDataGridViewTextBoxColumn";
            // 
            // парольDataGridViewTextBoxColumn
            // 
            this.парольDataGridViewTextBoxColumn.DataPropertyName = "Пароль";
            this.парольDataGridViewTextBoxColumn.HeaderText = "Пароль";
            this.парольDataGridViewTextBoxColumn.Name = "парольDataGridViewTextBoxColumn";
            // 
            // рольDataGridViewTextBoxColumn
            // 
            this.рольDataGridViewTextBoxColumn.DataPropertyName = "Роль";
            this.рольDataGridViewTextBoxColumn.HeaderText = "Роль";
            this.рольDataGridViewTextBoxColumn.Name = "рольDataGridViewTextBoxColumn";
            // 
            // пользователиBindingSource4
            // 
            this.пользователиBindingSource4.DataMember = "Пользователи";
            this.пользователиBindingSource4.DataSource = this.____Тихонова_4_курс_практикаDataSet;
            // 
            // ____Тихонова_4_курс_практикаDataSet
            // 
            this.____Тихонова_4_курс_практикаDataSet.DataSetName = "____Тихонова_4_курс_практикаDataSet";
            this.____Тихонова_4_курс_практикаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // пользователиBindingSource3
            // 
            this.пользователиBindingSource3.DataMember = "пользователи";
            this.пользователиBindingSource3.DataSource = this.____Tihonova_TuristichClubDataSet8;
            // 
            // ____Tihonova_TuristichClubDataSet8
            // 
            this.____Tihonova_TuristichClubDataSet8.DataSetName = "____Tihonova_TuristichClubDataSet8";
            this.____Tihonova_TuristichClubDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // пользователиTableAdapter3
            // 
            this.пользователиTableAdapter3.ClearBeforeFill = true;
            // 
            // пользователиTableAdapter4
            // 
            this.пользователиTableAdapter4.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::_17.Properties.Resources._4;
            this.pictureBox1.Location = new System.Drawing.Point(0, 214);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(612, 315);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(243, 177);
            this.textBox3.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(148, 28);
            this.textBox3.TabIndex = 14;
            this.textBox3.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(83, 180);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 21);
            this.label3.TabIndex = 13;
            this.label3.Text = "Введите телефон:";
            this.label3.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(610, 528);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.Name = "Form2";
            this.Text = "Вход";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Тихонова_4_курс_практикаDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.____Tihonova_TuristichClubDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
      
        private System.Windows.Forms.BindingSource usersBindingSource;
        
        private System.Windows.Forms.BindingSource usersBindingSource1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private ____Tihonova_TuristichClubDataSet ____Tihonova_TuristichClubDataSet;
        private System.Windows.Forms.BindingSource пользователиBindingSource;
        private ____Tihonova_TuristichClubDataSetTableAdapters.пользователиTableAdapter пользователиTableAdapter;
        private ____Tihonova_TuristichClubDataSet1 ____Tihonova_TuristichClubDataSet1;
        private System.Windows.Forms.BindingSource пользователиBindingSource1;
        private ____Tihonova_TuristichClubDataSet1TableAdapters.пользователиTableAdapter пользователиTableAdapter1;
        private ____Tihonova_TuristichClubDataSet7 ____Tihonova_TuristichClubDataSet7;
        private System.Windows.Forms.BindingSource пользователиBindingSource2;
        private ____Tihonova_TuristichClubDataSet7TableAdapters.пользователиTableAdapter пользователиTableAdapter2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private ____Tihonova_TuristichClubDataSet8 ____Tihonova_TuristichClubDataSet8;
        private System.Windows.Forms.BindingSource пользователиBindingSource3;
        private ____Tihonova_TuristichClubDataSet8TableAdapters.пользователиTableAdapter пользователиTableAdapter3;
        private ____Тихонова_4_курс_практикаDataSet ____Тихонова_4_курс_практикаDataSet;
        private System.Windows.Forms.BindingSource пользователиBindingSource4;
        private ____Тихонова_4_курс_практикаDataSetTableAdapters.ПользователиTableAdapter пользователиTableAdapter4;
        private System.Windows.Forms.DataGridViewTextBoxColumn логинDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn парольDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn рольDataGridViewTextBoxColumn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
    }
}